MouseGestures - pure Java library for recognition and processing mouse gestures.
=====================================================
version 1.2

Information
-----------
Jar files and API documentation are located in the 'dist' directory.
Test frame is in the separate jar (test.jar) and the library does not depend on it.

Product Home Page:

   http://www.smardec.com/products/mouse.html

Support:

   mouse@smardec.com


Other Stuff
-----------
This software is distributed under the terms of the GNU Lesser General Public License (see lgpl.txt).

If you want to contribute, contact mouse@smardec.com



Copyright (C) 2003-2004 Smardec

http://www.smardec.com
